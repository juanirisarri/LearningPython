

def sumar(n1,n2):
    sum = n1+n2
    print( "La suma es: ", str(sum) )


def restar(n1,n2):
    res = n1-n2
    print( "La resta es: ", str(res) )


def multiplicar(n1,n2):
    mul = n1*n2
    print( "La multiplicación es: ", str(mul) )


def dividir(n1,n2):
    div = n1/n2
    print( "La división es: ", str(div) )