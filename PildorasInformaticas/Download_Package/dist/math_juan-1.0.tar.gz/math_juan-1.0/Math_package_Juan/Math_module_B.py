

def redondear(n):
    red = round (n) 
    print( "El redondeo es: ", str(red) )




















